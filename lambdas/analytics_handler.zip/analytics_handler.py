def handler(event, context):
    print("Event: ", event)
    print("Context: ", context)
    print("Analytics processed successfully.")
