def handler(event, context):
    print("Event: ", event)
    print("Context: ", context)
    print("Payment processed successfully.")
