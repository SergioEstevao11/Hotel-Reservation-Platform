def handler(event, context):
    print("Event: ", event)
    print("Context: ", context)
    print("Update processed successfully.")
